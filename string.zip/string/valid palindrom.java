class Solution {
    public boolean isPalindrome(String a) {

        a = a.toLowerCase();

        String str = "";

        for (int i = 0; i < a.length(); i++) {

            char c = a.charAt(i);

            if (Character.isLetterOrDigit(c)) {
                str = str + c;
            }
        }

        int left = 0;
        int right = str.length() - 1;

        while (left < right) {

            if (str.charAt(left) != str.charAt(right)) {
                return false;
            }

            left++;
            right--;
        }

        return true;
    }
}