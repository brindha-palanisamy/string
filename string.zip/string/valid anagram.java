class Solution {
    public boolean isAnagram(String S1, String S2) {
        
        char[]a=S1.toCharArray();
        char[]b=S2.toCharArray();
        Arrays.sort(a);
        Arrays.sort(b);
        if(Arrays.equals(a,b)){
            return true;
        }
        return false;
        
    }
}
    